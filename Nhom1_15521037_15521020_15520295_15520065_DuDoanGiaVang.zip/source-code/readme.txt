Hướng dẫn chạy
1. Vô Google Drive, tạo thư mục 'colab/demand-forecast' và up file 'gld.csv' trong thư mục 'data' lên
2. Vô Google Colab https://colab.research.google.com/ up file Last90dayValidation.ipynb hoặc WalkForwaldValidation.ipynb lên Google Colab 
3. Chọn Runtime -> Change runtime type. Trong mục Hardware accelerator, chọn GPU. Nhấn Save. 
4. Chọn Runtime -> Run all để chạy. Lưu ý, trong lúc chạy sẽ thông báo truy cập vào link Google Drive để cấp quyền truy cập vào Google Drive ở cell thứ 2. 